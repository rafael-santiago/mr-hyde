/*
 * #Unit1.cpp#
 * por rafael santiago
 *
 * esse c�digo implementa esteganografia
 * em mensagens de IRC
 *
 */
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include <stdio.h>
#include <clipbrd.hpp>

#define IRCCOLORTOK ''
#define TOK 0x0a
#define getbitfromvalue(x,b) ( x << b >> 7 & 1 )

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
/*
 * gera uma cor rand�mica entre 0-9
 */
unsigned char TForm1::genRandomColor(void){
 return((rand()%10) + 48);
}
/*
 * esteganografa um bit no bit menos significante da cor
 */
unsigned char TForm1::hideBit(unsigned char bit, unsigned char color){
 return(getbitfromvalue(color,0) << 7 |
        getbitfromvalue(color,1) << 6 |
        getbitfromvalue(color,2) << 5 |
        getbitfromvalue(color,3) << 4 |
        getbitfromvalue(color,4) << 3 |
        getbitfromvalue(color,5) << 2 |
        getbitfromvalue(color,6) << 1 |
        bit);
}
/*
 * esteganografa uma mensagem em uma mensagem de cobertura
 * com c�digos de cores usadas em IRC
 */
void TForm1::ircMessageHideIn(unsigned char *message, int size, unsigned char *skin, unsigned char *steg){
 unsigned char buffer[45], *pskin=skin, byte, temp;
 unsigned char textcolor=-1, textbackground=-1;
 int i, j, walker;
 sprintf(buffer,"%d",size);
 memset(steg,'\0',sizeof(steg)*8);
 /*
  * esteganografando o tamanho real da mensagem
  */
 for(i=0,walker=0;buffer[i]!='\0';i++){
  byte = buffer[i];
  for(j=0;j<8;j+=2){/*escondendo os bits do byte atual*/
   steg[walker++]   = IRCCOLORTOK;
   _getColors:
    textcolor      = genRandomColor();
    textbackground = genRandomColor();
    textcolor      = hideBit(getbitfromvalue(byte,j),textcolor);
    textbackground = hideBit(getbitfromvalue(byte,j+1),textbackground);
    if(textcolor == textbackground) goto _getColors;
   ;
   steg[walker++] = textcolor;
   steg[walker++] = ',';
   steg[walker++] = textbackground;
   steg[walker++] = *skin;
   skin++;
   if(!(*skin)) skin = pskin;
  }
 }
 /*
  * inserindo o token
  */
 byte = TOK;
 for(j=0;j<8;j+=2){/*escondendo os bits do byte atual*/
  steg[walker++]   = IRCCOLORTOK;
  __getColors:
   textcolor      = genRandomColor();
   textbackground = genRandomColor();
   textcolor      = hideBit(getbitfromvalue(byte,j),textcolor);
   textbackground = hideBit(getbitfromvalue(byte,j+1),textbackground);
   if(textcolor == textbackground) goto __getColors;
  ;
  steg[walker++] = textcolor;
  steg[walker++] = ',';
  steg[walker++] = textbackground;
  steg[walker++] = *skin;
  skin++;
  if(!(*skin)) skin = pskin;
 }
 /*
  * escondendo a mensagem
  */
 for(i=0;i<size;i++){
  byte = message[i];
  for(j=0;j<8;j+=2){/*escondendo os bits do byte atual*/
   steg[walker++]   = IRCCOLORTOK;
   ___getColors:
    textcolor      = genRandomColor();
    textbackground = genRandomColor();
    textcolor      = hideBit(getbitfromvalue(byte,j),textcolor);
    textbackground = hideBit(getbitfromvalue(byte,j+1),textbackground);
    if(textcolor == textbackground) goto ___getColors;
   ;
   steg[walker++] = textcolor;
   steg[walker++] = ',';
   steg[walker++] = textbackground;
   steg[walker++] = *skin;
   steg[walker]='\0';
   skin++;
   if(!(*skin)) skin = pskin;
  }
 }
 while(*skin){
  steg[walker++]   = IRCCOLORTOK;
  ____getColors:
   textcolor      = genRandomColor();
   textbackground = genRandomColor();
   if(textcolor == textbackground) goto ____getColors;
  ;
  steg[walker++] = textcolor;
  steg[walker++] = ',';
  steg[walker++] = textbackground;
  steg[walker++] = *skin;
  steg[walker]='\0';
  skin++;
 }
 skin = pskin;
}
//---------------------------------------------------------------------------
/*
 * splita um esteganograma em n partes delimitadas por n espa�os
 */
void TForm1::splitMessageIntoList(unsigned char *message, int wordsPerMessage, TListBox *messagelist){
 int i,j,spaces;
 unsigned char temp[65535];
 AnsiString foo;
 memset(temp,'\0',sizeof(temp));
 messagelist->Items->Clear();
 for(i=0,j=0,spaces=0;message[i]!='\0';temp[j++] = message[i++],temp[j]=0){
  if(message[i]==32){
   spaces++;
   temp[j++] = '_'; //message[i++];
   i++;
   temp[j]   = 0;
   if(spaces == wordsPerMessage){
    foo.printf("%s",temp);
    j=spaces=0;
    messagelist->Items->Add(foo);
   }
  }
 }
 if(j>0 && strlen(temp)>0){
  foo.printf("%s",temp);
  messagelist->Items->Add(foo);
 }
}
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnHideClick(TObject *Sender)
{
 unsigned char result[65535];
 randomize();
 if(edtMessage->Text.Length()>0 && edtSkin->Text.Length()>0){
  ircMessageHideIn(edtMessage->Text.c_str(),edtMessage->Text.Length(),edtSkin->Text.c_str(),result);
  if(messageSplit->Checked)
   splitMessageIntoList(result,StrToInt(edtWordsTotal->Text),IRCString);
  else
   splitMessageIntoList(result,0,IRCString);
  edtMessage->Clear(); 
 }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnClipboardClick(TObject *Sender)
{
 TClipboard *clipboard = new TClipboard();
 if(IRCString->ItemIndex>-1) clipboard->SetTextBuf(IRCString->Items->Strings[IRCString->ItemIndex].c_str());
 delete(clipboard);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::IRCStringMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
 if(IRCString->ItemIndex>-1) IRCString->Hint = IRCString->Items->Strings[IRCString->ItemIndex];
}
//---------------------------------------------------------------------------
/*
 * extrai a mensagem do esteganograma
 *
 * 1 bit precisa de 5 caracteres... 1 char = 5*4 = 20
 * tamanho base = 20 * 2 = 40
 * tamanho da mensagem = tam * 5 = x
 * tam = ao tamanho original da mensagem em bytes * 4
 */
int TForm1::ircMessageHideOut(unsigned char *ircmessage, unsigned char *result){
 int size, ssize;
 int i, j,z;
 unsigned char buf[32], byte;
 /*
  * recuperando o tamanho da mensagem
  */
  for(i=0,byte=0,size=0;ircmessage[i]!='\0' && byte!=TOK;){
   byte=0;
   j=0;
   /*\03n,nc*/
   while(j<8){
    byte = byte << 2 | getbitfromvalue((ircmessage[i+1] - 48),7) << 1
                     | getbitfromvalue((ircmessage[i+3] - 48),7);
    j+=2;
    i+=5;
   }
   if(byte!=TOK) buf[size++] = byte;
  }
  if(byte!=TOK){
   MessageDlg("m e n s a g e m  corrompida!",mtError,TMsgDlgButtons()<<mbOK,0);
   return(0);
  }
  /*
   * checando fragmenta��o da mensagem...
   */
  size  = atoi(buf);
  ssize = (size*4) * 5;
  for(j=i,z=0;ircmessage[j]!='\0';j++,z++);
  if(z<ssize){
   MessageDlg("m e n s a g e m  fragmentada!",mtWarning,TMsgDlgButtons()<<mbOK,0);
   return(0);
  }
  /*
   * recuperando a mensagem
   */
  for(ssize=0;ssize<size && ircmessage[i]!='\0';){
   j=0;
   byte=0;
   while(j<8){
    byte = byte << 2 | getbitfromvalue(ircmessage[i+1],7) << 1
                     | getbitfromvalue(ircmessage[i+3],7);
    j+=2;
    i+=5;
   }
   result[ssize++] = byte;
   result[ssize]   = 0;
  }
 return(1); 
}
void __fastcall TForm1::btnShowClick(TObject *Sender)
{
 unsigned char result[65535];
 AnsiString foo;
 if(ircMessageHideOut(edtSkin->Text.c_str(),result)){
  foo.printf("%s",result);
  edtMessage->Text = foo;
 }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::edtMessageKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
 if(Key==VK_RETURN)
  btnHide->OnClick(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::edtSkinKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
 if(Key==VK_RETURN)
  btnShow->OnClick(Sender);        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IRCStringKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
 if(Key==VK_RETURN)
  btnClipboard->OnClick(Sender);        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::limpar1Click(TObject *Sender)
{
 IRCString->Items->Clear();        
}
//---------------------------------------------------------------------------

