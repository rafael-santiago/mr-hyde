//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TEdit *edtSkin;
        TEdit *edtMessage;
        TLabel *Label2;
        TBitBtn *btnHide;
        TBitBtn *btnShow;
        TLabel *Label3;
        TBitBtn *btnClipboard;
        TImage *Image1;
        TImage *Image2;
        TListBox *IRCString;
        TLabel *Label4;
        TUpDown *UpDown1;
        TEdit *edtWordsTotal;
        TCheckBox *messageSplit;
        TImage *Image3;
        TImage *Image4;
        TPopupMenu *PopupMenu1;
        TMenuItem *limpar1;
        void __fastcall btnHideClick(TObject *Sender);
        void __fastcall btnClipboardClick(TObject *Sender);
        void __fastcall IRCStringMouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall btnShowClick(TObject *Sender);
        void __fastcall edtMessageKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall edtSkinKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall IRCStringKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall limpar1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
        void ircMessageHideIn(unsigned char *, int, unsigned char *, unsigned char *);
        unsigned char genRandomColor(void);
        unsigned char hideBit(unsigned char, unsigned char);
        void splitMessageIntoList(unsigned char *, int, TListBox *);
        int ircMessageHideOut(unsigned char *, unsigned char *);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
